package com.powerrangers.system.modules.UserAccess.service.dto;

import com.powerrangers.system.modules.UserAccess.domain.User;
import lombok.Data;

@Data
public class UserDTO extends User {
}
