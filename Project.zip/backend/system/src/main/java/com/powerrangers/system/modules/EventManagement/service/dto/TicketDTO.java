package com.powerrangers.system.modules.EventManagement.service.dto;

import com.powerrangers.system.modules.EventManagement.domain.Ticket;
import lombok.Data;

@Data
public class TicketDTO extends Ticket {
}
