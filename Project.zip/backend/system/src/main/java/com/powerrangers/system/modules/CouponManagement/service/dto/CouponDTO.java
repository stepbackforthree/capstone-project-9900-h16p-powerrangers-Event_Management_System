package com.powerrangers.system.modules.CouponManagement.service.dto;

import com.powerrangers.system.modules.CouponManagement.domain.Coupon;
import lombok.Data;

import java.math.BigDecimal;
import java.sql.Timestamp;

@Data
public class CouponDTO extends Coupon {
}
