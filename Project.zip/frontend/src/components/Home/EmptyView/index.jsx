import React from 'react'

export default function EmptyView() {
  return (
    <div>EmptyView</div>
  )
}
